﻿1.For login page,you need to use the following values to pass the validation:
"Username":"user"
"Password":"user"

2.In login.html,in "Forgot Password" screen,you need to enter "abc@123.com" to pass the validation

3.Please ignore the errors and warnings in jquery.ui.css,this is a css file of 3rd party library.